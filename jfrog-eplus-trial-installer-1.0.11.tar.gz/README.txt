JFrog Enterprise Plus Trial
===========================

Install and setup instructions are located https://www.jfrog.com/confluence/display/EP/Installing+Enterprise+Plus+Trial


Help
----
sudo ./runeplus.sh help

