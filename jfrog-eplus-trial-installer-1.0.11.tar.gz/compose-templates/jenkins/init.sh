#!/bin/sh
cd "$(dirname "$0")"
echo "Changing mount folder owner to jenkins user"
chown -R 104:107 WORK_DIR/jfrog/data/jenkins