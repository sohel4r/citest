#!/bin/sh
cd "$(dirname "$0")"

echo "Launching docker compose..."
docker-compose up -d