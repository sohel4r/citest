#!/bin/sh
cd "$(dirname "$0")"

echo "Tearing down docker compose..."
docker-compose down