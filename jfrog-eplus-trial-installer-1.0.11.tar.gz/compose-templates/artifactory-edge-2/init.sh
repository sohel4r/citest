#!/bin/sh
cd "$(dirname "$0")"
echo "Changing mount folder owner to artifactory user"
chown -R 1030:1030 WORK_DIR/jfrog/data/artifactory-edge-2/backup
chown -R 1030:1030 WORK_DIR/jfrog/data/artifactory-edge-2/ha
chown -R 1030:1030 WORK_DIR/jfrog/data/artifactory-edge-2/node1
chown -R 104:107 WORK_DIR/jfrog/data/artifactory-edge-2/nginx
