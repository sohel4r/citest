#!/bin/sh
cd "$(dirname "$0")"

echo "Changing mount folder owner to distribution user"
chown -R 1020:1020 WORK_DIR/jfrog/data/distribution