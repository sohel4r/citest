#!/bin/sh
cd "$(dirname "$0")"

echo "Changing mount folder owner to xray user"
chown -R 1035:1035 WORK_DIR/jfrog/data/xray/node1
chown -R 1035:1035 WORK_DIR/jfrog/data/xray/node2
chown -R 104:107 WORK_DIR/jfrog/data/xray/nginx
