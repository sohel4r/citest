#!/usr/bin/env bash

cd "$(dirname "$0")"

echo "Changing mount folder owner to JFMC user"
chown -R 1050:1050 WORK_DIR/jfrog/data/mc/jfmc