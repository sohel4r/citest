#!/bin/bash


# Initialize some times. Will update these with actual times as we
# satrt processing. In the end we can print summary and do some calulations
# as well.
STARTUP_BEGIN_TIME=0
STARTUP_END_TIME=0

INIT_BEGIN_TIME=0
INIT_END_TIME=0

UP_BEGIN_TIME=0
UP_END_TIME=0

DOWNLOAD_BEGIN_TIME=0
DOWNLOAD_END_TIME=0

REQD_SPACE_IN_G="75G"
REQD_SPACE_IN_K=78643200


errorExit () {
    echo; echo "ERROR: $1" |& tee -a logfile ; echo
    exit 1
}

# wait until service is up
wait_for_service() {
    local retries=$1
    local url=$2
    echo "Waiting for service $url. Retries left: $retries"
    local error=false
    local response=$(curl --connect-timeout 10 --max-time 10 --retry 5 --retry-delay 2 --retry-max-time 60 -L -k --fail --silent -o /dev/null -w "%{http_code}" $url)

    if [ "${response}" == "200" ]; then
        echo "SUCCESS: returned 200"
    else
        echo "FAILED: failed with http code ${response}"
        error=true
    fi

    # If errors found, wait and try again
    if [ "${error}" == true ]; then
        if [ "${retries}" -gt 0 ]; then
            echo "** Errors found. Allowing more time for services to come up and retrying"
            sleep 30
            wait_for_service $((retries - 1)) $url
        else
            errorExit "Service $url not available"
        fi
    else
        echo "Service $url is up"
    fi

}

prereqcheck() {
     echo "Doing prerequisite check ...";

     freek=`df -k --output=avail "$PWD" | tail -n1`   
     freeg=$((freek/(1024*1024)))
     echo "Free disk space available $freek k($freeg). Diskspace required : $REQD_SPACE_IN_K kb"
     if [ $freek -le $REQD_SPACE_IN_K ]; then             
         echo "Please free up some space and rerun ..."
         exit 1;
     fi;

     if [ -f /usr/bin/free ]; then
         mem=`free -m  | grep Mem | awk '{print $2}'`
         if [ $mem -lt 25000 ]; then
             echo "Insufficient memory in system < 25G ";
             exit 1;
         fi;
     fi;


     if [ ! -f /usr/bin/curl ]; then
         a=`which curl`
         count=`echo -n $a | wc -c`
         if [ $count -eq 0 ]; then
             echo "curl is not installed .. Cannot continue, please install curl and rerun .."
             exit 1;
         fi
     fi

     if [ ! -f /usr/bin/perl ]; then
         a=`which perl`
         count=`echo -n $a | wc -c`
         if [ $count -eq 0 ]; then
             echo "perl is not installed .. Cannot continue, please install perl and rerun .."
             exit 1;
         fi
     fi

     if [ ! -f /usr/bin/shasum ]; then
         a=`which shasum`
         count=`echo -n $a | wc -c`
         if [ $count -eq 0 ]; then
             echo "shasum is not installed .. Cannot continue, please install shasum and rerun .."
             exit 1;
         fi
     fi
     if [ ! -f /usr/bin/docker ]; then
         a=`which docker`
         count=`echo -n $a | wc -c`
         if [ $count -eq 0 ]; then
             echo "Docker is not installed .. Cannot continue, please install docker and rerun .."
             exit 1;
         fi
     fi
     if [ ! -f /usr/bin/docker-compose ]; then
         a=`which docker-compose`
         count=`echo -n $a | wc -c`
         if [ $count -eq 0 ]; then
             echo "Docker-compose is not installed .. Cannot continue, please install docker-compose and rerun .."
             exit 1;
         fi
     fi
     if [ ! -f /usr/bin/unzip ]; then
         a=`which unzip`
         count=`echo -n $a | wc -c`
         if [ $count -eq 0 ]; then
             echo "unzip is not installed .. Trying to install unzip .."
             if [[ $(uname -s) = "Darwin" ]]; then
                 echo "This is macOS. Using brew to instal unzip .."
                 brew install unzip
             else
                 if [ -f /etc/redhat-release ]; then
                    echo "RedHat flavor of unix, Using yum install unzip -y"
                    yum install unzip
                 else
                     if [  -n "$(uname -a | grep Ubuntu)" ]; then
                        echo "Ubuntu, Using sudo apt install unzip ..."
                        sudo apt install unzip
                     else
                        echo "Not ubuntu, Trying apt or yum whichever works.."
                        sudo apt install unzip || yum install unzip 
                     fi
                 fi
             fi
         fi
         # Let us recheck if unzip got installed succesfully
         a=`which unzip`
         count=`echo -n $a | wc -c`
         if [ $count -eq 0 ]; then
              echo "Unzip installation cannot be confirmed .. Please manually install unzip and rerun .."
              exit 1;
         fi
     fi
}

startup() {
    STARTUP_BEGIN_TIME=$(date +%s);
    init;
    up;
    STARTUP_END_TIME=$(date +%s);
}


init() {
        INIT_BEGIN_TIME=$(date +%s);
        prereqcheck;
        echo "Doing initial setup ...";
        backup=backup-prev-`date "+%Y-%m-%d-%H%M%S"`
        if [ -d compose-templates ]; then
            echo "compose-templates exists probably from a prior init .."
            echo "Creating Backup directory $backup ..."
            mkdir $backup
            chmod 777 $backup
            echo "Saving compose-templates to $backup"
            cp -r  compose-templates $backup
            if [ -d scripts ]; then
                echo "Saving scripts to $backup"
                cp -r  scripts $backup
            fi
        else
            echo "compose-templates directory does not exist .."
            echo "Cannot continue .. Please get the package from bintray and try .."
            exit 1
        fi

#       Download from bintray the zip file for eplusdemo
#       unzip, extract etc to find 2 directories compose-templates and scripts 
#       If these two directories are not found, no point in pursuing...

        download_url="https://dl.bintray.com/jfrog/enterprise-trial-installer"

        zip_file1="jfrog/artifactoryedge1/artifactoryedge1-1.0.11.zip"
        zip_file2="jfrog/artifactoryedge2/artifactoryedge2-1.0.11.zip"
        zip_file3="jfrog/artifactoryha1/artifactoryha1-1.0.11.zip"
        zip_file4="jfrog/artifactorypro1/artifactorypro1-1.0.11.zip"
        zip_file5="jfrog/distribution/distribution-1.0.11.zip"
        zip_file6="jfrog/jenkins/jenkins-1.0.11.zip"
        zip_file7="jfrog/mc/mc-1.0.11.zip"
        zip_file8="jfrog/xray/xray-1.0.11.zip"

        zip_files="$zip_file1 $zip_file2 $zip_file3 $zip_file4 $zip_file5 $zip_file6 $zip_file7 $zip_file8"
        DOWNLOAD_BEGIN_TIME=$(date +%s);
        for i in $zip_files; do
            echo "Removing $i locally incase it exists .."
            basefile=`basename $i`
            sudo /bin/rm  -f $basefile
            echo -n "Downloading $basefile"
            if [ -z "$DOWNLOAD_URL" ]; then
                echo " From bintray"
                curl -L -O $download_url/$i
            else
                echo " From $DOWNLOAD_URL"
                curl -L -O $DOWNLOAD_URL/$i
            fi
            if [ -s $basefile ]; then
                echo "Calculating SHA256 on the downloaded file : $basefile ...."
                SHA256=$(shasum -a 256 $basefile | awk '{print $1}')
                echo "Download $basefile done. SHA2=$SHA256"
                unzip -o $basefile
                echo Extracting  $basefile done
                sudo /bin/rm  -f $basefile
                echo Removed  $basefile
            else
                echo Downloading of $basefile has failed 
                echo Please check your credentials, network connectivity and rerun 
                exit 1;
            fi
        done
        DOWNLOAD_END_TIME=$(date +%s);

        work_dir=`pwd`

        yml_files=`find compose-templates -name docker-compose.yml`
        for i in $yml_files; do
            echo "Processing file $i to fix work directory in $i"
            mv $i $i.tmp
            sed -e "s:WORK_DIR:$work_dir:g" $i.tmp >  $i
            /bin/rm -f $i.tmp
            echo "Processing $i complete.."
        done

        init_files=`find compose-templates -name init.sh`
        for i in $init_files; do
            echo "Processing file $i to fix work directory in $i"
            mv $i $i.tmp
            sed -e "s:WORK_DIR:$work_dir:g" $i.tmp >  $i
            /bin/rm -f $i.tmp
            echo "Processing $i complete.."
            echo "Executing  $i ..."
            sudo bash "$i"
        done

        # remove any existing jfrog.local entry in /etc/hosts
        sudo bash -c  "sed -i '/jfrog.local/d' /etc/hosts"
        # Get local internal ip
        ip=`hostname -i`
        # add new entry for jfrog.local with the new internal ip address
        sudo bash -c  "echo $ip jfrog.local >> /etc/hosts"
        # sysctl vm.max_map_count to at least 262144
        sudo bash -c '/sbin/sysctl -w vm.max_map_count=262144'
        sudo bash -c "/bin/echo 'vm.max_map_count=262144' >> /etc/sysctl.conf"
        echo "Initial Setup Complete..."
        INIT_END_TIME=$(date +%s);

}


up() {
        UP_BEGIN_TIME=$(date +%s);

        if [ ! -d compose-templates ]; then
            echo "compose-templates directory does not exist .."
            echo "Please run init first ..."
            exit 1
        fi

        echo Executing compose-templates/artifactory-ha-1/up.sh first ..
        status=$(bash "compose-templates/artifactory-ha-1/up.sh" 2>&1)
        if [ $? -ne 0 ]; then
          echo Error encountered while running compose-templates/artifactory-ha-1/up.sh 
          echo This is the error message
          echo $status
          echo "Please address this issue first and rerun with the up option again"
          echo "Exiting now ..."
          exit 1
        fi
        echo Waiting for artifactory-ha-1 to come up ...
        sleep 30
        wait_for_service 5 "http://jfrog.local/artifactory/webapp/#/login"
        
        a=`find compose-templates -name up.sh | sort -d | grep -v "artifactory-ha-1" | grep -v "distribution"`
        for i in $a
        do
            echo Executing $i
            ls -l $i
            bash "$i"
        done

        # mission control would have been started in the loop above
        # just check if it is ready
        echo Checking to see if mission control is ready ..
        wait_for_service 5 "http://jfrog.local:8080/api/v3/ping"

        # we skipped distribution in above loop
        # start and check if it is ready 
        echo Executing compose-templates/distribution/up.sh last ..
        status=$(bash "compose-templates/distribution/up.sh" 2>&1)
        if [ $? -ne 0 ]; then
          echo Error encountered while running compose-templates/distribution/up.sh 
          echo This is the error message
          echo $status
          echo "Please try to start distribution manually, if not possible"
          echo "run the script with down option and rerun with option again"
          echo "Exiting now ..."
          exit 1
        fi

        echo Checking to see if distribution is ready ..
        wait_for_service 5 "http://jfrog.local:8083"

        UP_END_TIME=$(date +%s);
}


usage() {
    echo "Usage: $0 <help|startup|init|up|down> |& tee logfile "
    echo "     help    - display this message"
    echo "     init    - downloads zip files, modifies docker-compose.yml files and init scripts"
    echo "     startup - invokes init and up functions"
    echo "     up      - brings up all services "
    echo "     down    - brings down all services "
    echo "Pipe the output to tee logfile"
}

printheader() {
    echo "================================================="
    echo "               BEGIN STATISTICS                  " 
}
printfooter() {
    echo "               END STATISTICS                    " 
    echo "================================================="
}
printsummary() {
    printheader;
    DIFF=$(($STARTUP_END_TIME-$STARTUP_BEGIN_TIME))
    echo "TOTAL STARTUP TIME : $(($DIFF / 3600 )) hours $((($DIFF % 3600) / 60)) minutes $(($DIFF % 60)) seconds" 
    DIFF=$(($INIT_END_TIME-$INIT_BEGIN_TIME))
    echo "TOTAL INIT  TIME : $(($DIFF / 3600 )) hours $((($DIFF % 3600) / 60)) minutes $(($DIFF % 60)) seconds" 
    DIFF=$(($UP_END_TIME-$UP_BEGIN_TIME))
    echo "TOTAL TIME TO BRING UP ALL SERVICES: $(($DIFF / 3600 )) hours $((($DIFF % 3600) / 60)) minutes $(($DIFF % 60)) seconds" 

    DIFF=$(($DOWNLOAD_END_TIME-$DOWNLOAD_BEGIN_TIME))
    echo "TOTAL DOWNLOAD TIME : $(($DIFF / 3600 )) hours $((($DIFF % 3600) / 60)) minutes $(($DIFF % 60)) seconds" 

    printfooter;
}
printinitsummary() {

    printheader;
    DIFF=$(($INIT_END_TIME-$INIT_BEGIN_TIME))
    echo "TOTAL INIT  TIME : $(($DIFF / 3600 )) hours $((($DIFF % 3600) / 60)) minutes $(($DIFF % 60)) seconds" 
    DIFF=$(($DOWNLOAD_END_TIME-$DOWNLOAD_BEGIN_TIME))
    echo "TOTAL DOWNLOAD TIME : $(($DIFF / 3600 )) hours $((($DIFF % 3600) / 60)) minutes $(($DIFF % 60)) seconds" 
    printfooter;
}

printupsummary() {
    printheader;
    DIFF=$(($UP_END_TIME-$UP_BEGIN_TIME))
    echo "TOTAL TIME TO BRING UP ALL SERVICES: $(($DIFF / 3600 )) hours $((($DIFF % 3600) / 60)) minutes $(($DIFF % 60)) seconds" 
    printfooter;
}
printdownsummary() {
    echo "All Services have been shutdown ..."
}

printeplusdetails() {
    echo "Enterprise Plus installation details .."
    echo "
outputs:
- name: Username
  value: admin
- name: Password
  value: password123
- name: Artifactory (US) URL
  value: http://jfrog.local/artifactory/webapp
- name: Artifactory (EU) URL
  value: http://jfrog.local:8092/artifactory/webapp
- name: Mission Control URL
  value: http://jfrog.local:8080/
- name: Xray URL
  value: http://jfrog.local:8000/
- name: Distribution URL
  value: http://jfrog.local:8083/
- name: Artifactory Edge (US) URL
  value: http://jfrog.local:8090/artifactory/webapp
- name: Artifactory Edge (EU) URL
  value: http://jfrog.local:8091/artifactory/webapp
- name: Jenkins URL
  value: http://jfrog.local:8086/
"

echo "For more details, please review the online documentation at https://www.jfrog.com/confluence/display/EP/Installing+Enterprise+Plus+Trial"

}



if [ $# -ne 1 ]; then
    echo "Usage: $0 <help|startup|init|up|down> |& tee logfile"
    exit 1;
fi

case "$1" in 
    'help')
        usage;
        ;;
    'startup')
        startup;
        printsummary;
        printeplusdetails;
        ;;
    'init')
        init;
        printinitsummary;
        ;;
    'up')
        up;
        printupsummary;
        printeplusdetails;
        ;;

    'down')
        if [ ! -d compose-templates ]; then
            echo "compose-templates directory does not exist .."
            echo "Please run init first ..."
            exit 1
        fi
        a=`find compose-templates -name down.sh -print`
        for i in $a
        do
            echo Executing $i
            ls -l $i
            bash $i
        done
        printdownsummary;
        ;;

    *) 
        echo "$1 is not a supported option";
        usage;
        ;;
esac
